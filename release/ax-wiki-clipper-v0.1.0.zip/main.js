/*
AxeraWikiClipper — built 2026-04-23T13:36:35.399Z
*/
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// main.ts
var main_exports = {};
__export(main_exports, {
  default: () => AxWikiClipperPlugin
});
module.exports = __toCommonJS(main_exports);
var import_obsidian5 = require("obsidian");

// src/settings.ts
var import_obsidian = require("obsidian");

// src/utils/logger.ts
var PREFIX = "[AxeraWikiClipper]";
function defaultLevel() {
  const isProd = true;
  return isProd ? 20 /* INFO */ : 10 /* DEBUG */;
}
function overrideLevel() {
  try {
    if (typeof window !== "undefined" && window.AxWikiClipperDebug) {
      return 10 /* DEBUG */;
    }
  } catch {
  }
  return null;
}
function currentLevel() {
  return overrideLevel() ?? defaultLevel();
}
var logger = {
  debug(...args) {
    if (currentLevel() <= 10 /* DEBUG */)
      console.debug(PREFIX, ...args);
  },
  info(...args) {
    if (currentLevel() <= 20 /* INFO */)
      console.info(PREFIX, ...args);
  },
  warn(...args) {
    if (currentLevel() <= 30 /* WARN */)
      console.warn(PREFIX, ...args);
  },
  error(...args) {
    if (currentLevel() <= 40 /* ERROR */)
      console.error(PREFIX, ...args);
  },
  /** Force DEBUG for the rest of the session (called by the settings page button). */
  enableDebug() {
    try {
      window.AxWikiClipperDebug = true;
    } catch {
    }
  },
  /** Turn the runtime DEBUG override back off. */
  disableDebug() {
    try {
      window.AxWikiClipperDebug = false;
    } catch {
    }
  },
  /** Whether the runtime DEBUG override is currently active. */
  isDebugEnabled() {
    try {
      return !!window.AxWikiClipperDebug;
    } catch {
      return false;
    }
  }
};

// src/settings.ts
var DEFAULT_SETTINGS = {
  baseUrl: "https://wiki.aixin-chip.com",
  authMode: "basic",
  username: "",
  password: "",
  cookie: "",
  inboxPath: "inbox",
  filenameSource: "title",
  overwriteExisting: true,
  downloadAllAttachments: false,
  writeFrontmatter: true,
  linkStyle: "wikilink"
};
var HARDCODED = {
  concurrency: 8,
  timeoutMs: 3e4,
  attachmentPageSize: 200
};
var AxWikiClipperSettingTab = class extends import_obsidian.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  display() {
    const { containerEl } = this;
    containerEl.empty();
    containerEl.createEl("h2", { text: "Connection" });
    new import_obsidian.Setting(containerEl).setName("Wiki base URL").setDesc("Root of the Confluence site. No trailing slash.").addText(
      (t) => t.setPlaceholder("https://wiki.aixin-chip.com").setValue(this.plugin.settings.baseUrl).onChange(async (v) => {
        this.plugin.settings.baseUrl = v.trim().replace(/\/+$/, "");
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian.Setting(containerEl).setName("Authentication mode").setDesc("Basic Auth works on most sites. Use Cookie if your site enforces SSO.").addDropdown(
      (d) => d.addOption("basic", "Basic Auth (username + password)").addOption("cookie", "Cookie (paste from browser)").setValue(this.plugin.settings.authMode).onChange(async (v) => {
        this.plugin.settings.authMode = v;
        await this.plugin.saveSettings();
        this.display();
      })
    );
    if (this.plugin.settings.authMode === "basic") {
      new import_obsidian.Setting(containerEl).setName("Username").addText(
        (t) => t.setValue(this.plugin.settings.username).onChange(async (v) => {
          this.plugin.settings.username = v;
          await this.plugin.saveSettings();
        })
      );
      new import_obsidian.Setting(containerEl).setName("Password").setDesc("\u26A0 Stored as plain text in the vault's .obsidian/plugins/ax-wiki-clipper/data.json").addText((t) => {
        t.inputEl.type = "password";
        t.setValue(this.plugin.settings.password).onChange(async (v) => {
          this.plugin.settings.password = v;
          await this.plugin.saveSettings();
        });
      });
    } else {
      new import_obsidian.Setting(containerEl).setName("Cookie").setDesc("Paste the full Cookie header value. Get it from Chrome DevTools \u2192 Application \u2192 Cookies.").addTextArea((t) => {
        t.inputEl.rows = 3;
        t.setPlaceholder("JSESSIONID=...; seraph.confluence=...").setValue(this.plugin.settings.cookie).onChange(async (v) => {
          this.plugin.settings.cookie = v.trim();
          await this.plugin.saveSettings();
        });
      });
    }
    containerEl.createEl("h2", { text: "Storage" });
    new import_obsidian.Setting(containerEl).setName("Inbox folder").setDesc("Vault-relative folder where downloads are placed.").addText(
      (t) => t.setValue(this.plugin.settings.inboxPath).onChange(async (v) => {
        this.plugin.settings.inboxPath = v.trim().replace(/^\/+|\/+$/g, "") || "inbox";
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian.Setting(containerEl).setName("Filename source").setDesc("How to name the generated Markdown file.").addDropdown(
      (d) => d.addOption("title", "Page title").addOption("pageId", "Page ID").setValue(this.plugin.settings.filenameSource).onChange(async (v) => {
        this.plugin.settings.filenameSource = v;
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian.Setting(containerEl).setName("Overwrite existing files").setDesc("If off, the command skips pages whose Markdown file already exists.").addToggle(
      (t) => t.setValue(this.plugin.settings.overwriteExisting).onChange(async (v) => {
        this.plugin.settings.overwriteExisting = v;
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian.Setting(containerEl).setName("Download all attachments").setDesc("If off, only attachments referenced in the page body are downloaded.").addToggle(
      (t) => t.setValue(this.plugin.settings.downloadAllAttachments).onChange(async (v) => {
        this.plugin.settings.downloadAllAttachments = v;
        await this.plugin.saveSettings();
      })
    );
    containerEl.createEl("h2", { text: "Markdown" });
    new import_obsidian.Setting(containerEl).setName("Write frontmatter").setDesc("Prepend YAML frontmatter (source, pageId, spaceKey, version, originalTitle, fetchedAt).").addToggle(
      (t) => t.setValue(this.plugin.settings.writeFrontmatter).onChange(async (v) => {
        this.plugin.settings.writeFrontmatter = v;
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian.Setting(containerEl).setName("Attachment link style").setDesc(
      "How to reference downloaded attachments in the note body. Wikilink works only inside Obsidian; standard Markdown is portable."
    ).addDropdown(
      (d) => d.addOption("wikilink", "Obsidian wikilink  ![[path]]").addOption("markdown", "Standard Markdown  ![](path)").setValue(this.plugin.settings.linkStyle).onChange(async (v) => {
        this.plugin.settings.linkStyle = v;
        await this.plugin.saveSettings();
      })
    );
    containerEl.createEl("h2", { text: "Troubleshooting" });
    new import_obsidian.Setting(containerEl).setName("Enable debug logs").setDesc(
      "Turns on verbose console logging for this session. Open DevTools with Ctrl+Shift+I to view."
    ).addToggle(
      (t) => t.setValue(logger.isDebugEnabled()).onChange((v) => {
        if (v) {
          logger.enableDebug();
          new import_obsidian.Notice("Debug logs enabled. Open DevTools (Ctrl+Shift+I) to view.");
        } else {
          logger.disableDebug();
          new import_obsidian.Notice("Debug logs disabled.");
        }
      })
    );
  }
};

// src/confluence/pipeline.ts
var import_obsidian3 = require("obsidian");

// src/confluence/client.ts
var import_obsidian2 = require("obsidian");
var AuthError = class extends Error {
  constructor(message) {
    super(message);
    this.name = "AuthError";
  }
};
var NotFoundError = class extends Error {
  constructor(message) {
    super(message);
    this.name = "NotFoundError";
  }
};
var HttpError = class extends Error {
  constructor(status, message) {
    super(message);
    this.name = "HttpError";
    this.status = status;
  }
};
var ConfluenceClient = class {
  constructor(settings) {
    this.settings = settings;
  }
  get baseUrl() {
    return this.settings.baseUrl.replace(/\/+$/, "");
  }
  buildHeaders(extra) {
    const h = {
      Accept: "application/json, */*",
      "X-Atlassian-Token": "no-check",
      ...extra ?? {}
    };
    if (this.settings.authMode === "basic") {
      const u = this.settings.username;
      const p = this.settings.password;
      if (u && p) {
        h["Authorization"] = "Basic " + btoa(`${u}:${p}`);
      }
    } else if (this.settings.authMode === "cookie") {
      if (this.settings.cookie)
        h["Cookie"] = this.settings.cookie;
    }
    return h;
  }
  async request(params) {
    logger.debug("HTTP", params.method ?? "GET", params.url);
    let res;
    try {
      res = await (0, import_obsidian2.requestUrl)({ throw: false, ...params });
    } catch (e) {
      throw new HttpError(0, `Network error: ${e.message}`);
    }
    logger.debug("HTTP", res.status, params.url);
    if (res.status === 401 || res.status === 403) {
      throw new AuthError(
        `Authentication failed (HTTP ${res.status}). Check your ${this.settings.authMode === "basic" ? "username/password" : "cookie"} in settings.`
      );
    }
    if (res.status === 404) {
      throw new NotFoundError(`Not found (HTTP 404): ${params.url}`);
    }
    if (res.status >= 400) {
      throw new HttpError(res.status, `HTTP ${res.status}: ${params.url}`);
    }
    return res;
  }
  async getPage(pageId) {
    const url = `${this.baseUrl}/rest/api/content/${encodeURIComponent(
      pageId
    )}?expand=body.storage,title,version,space,history,history.lastUpdated`;
    const res = await this.request({ url, method: "GET", headers: this.buildHeaders() });
    const json = res.json;
    const storage = json.body?.storage?.value ?? "";
    const webRel = json._links?.webui ?? `/pages/viewpage.action?pageId=${pageId}`;
    const createdBy = json.history?.createdBy?.displayName ?? json.history?.createdBy?.username ?? "";
    const createdAt = json.history?.createdDate ?? "";
    const lastUpdated = json.history?.lastUpdated;
    const lastModifiedBy = lastUpdated?.by?.displayName ?? lastUpdated?.by?.username ?? json.version?.by?.displayName ?? json.version?.by?.username ?? "";
    const lastModifiedAt = lastUpdated?.when ?? json.version?.when ?? "";
    return {
      id: json.id,
      title: json.title,
      spaceKey: json.space?.key ?? "",
      version: json.version?.number ?? 0,
      storageXhtml: storage,
      webUrl: `${this.baseUrl}${webRel}`,
      createdBy,
      createdAt,
      lastModifiedBy,
      lastModifiedAt
    };
  }
  async listAttachments(pageId) {
    const out = [];
    let next2 = `${this.baseUrl}/rest/api/content/${encodeURIComponent(
      pageId
    )}/child/attachment?limit=${HARDCODED.attachmentPageSize}`;
    let guard = 0;
    while (next2 && guard < 50) {
      guard++;
      const res = await this.request({ url: next2, method: "GET", headers: this.buildHeaders() });
      const json = res.json;
      for (const r of json.results ?? []) {
        out.push({
          id: r.id,
          title: r.title,
          mediaType: r.extensions?.mediaType ?? "",
          fileSize: r.extensions?.fileSize ?? 0,
          downloadPath: r._links?.download ?? ""
        });
      }
      const rel = json._links?.next;
      next2 = rel ? `${this.baseUrl}${rel}` : null;
    }
    return out;
  }
  async downloadAttachment(siteRelativePath) {
    const buildUrl = (p) => p.startsWith("http") ? p : `${this.baseUrl}${p.startsWith("/") ? "" : "/"}${p}`;
    const primary = buildUrl(siteRelativePath);
    const pathOnly = siteRelativePath.split(/[?#]/, 1)[0];
    const fallback = buildUrl(pathOnly);
    try {
      const res = await this.request({
        url: primary,
        method: "GET",
        headers: this.buildHeaders()
      });
      return res.arrayBuffer;
    } catch (e) {
      const msg = e.message || "";
      const isRedirectLoop = msg.includes("ERR_TOO_MANY_REDIRECTS") || msg.includes("redirect");
      if (!isRedirectLoop || fallback === primary)
        throw e;
      logger.warn(
        "Attachment download hit redirect loop; retrying without query string:",
        fallback
      );
      const res = await this.request({
        url: fallback,
        method: "GET",
        headers: this.buildHeaders()
      });
      return res.arrayBuffer;
    }
  }
};

// node_modules/turndown/lib/turndown.browser.es.js
function extend(destination) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i];
    for (var key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key))
        destination[key] = source[key];
    }
  }
  return destination;
}
function repeat(character, count) {
  return Array(count + 1).join(character);
}
function trimLeadingNewlines(string) {
  return string.replace(/^\n*/, "");
}
function trimTrailingNewlines(string) {
  var indexEnd = string.length;
  while (indexEnd > 0 && string[indexEnd - 1] === "\n")
    indexEnd--;
  return string.substring(0, indexEnd);
}
function trimNewlines(string) {
  return trimTrailingNewlines(trimLeadingNewlines(string));
}
var blockElements = ["ADDRESS", "ARTICLE", "ASIDE", "AUDIO", "BLOCKQUOTE", "BODY", "CANVAS", "CENTER", "DD", "DIR", "DIV", "DL", "DT", "FIELDSET", "FIGCAPTION", "FIGURE", "FOOTER", "FORM", "FRAMESET", "H1", "H2", "H3", "H4", "H5", "H6", "HEADER", "HGROUP", "HR", "HTML", "ISINDEX", "LI", "MAIN", "MENU", "NAV", "NOFRAMES", "NOSCRIPT", "OL", "OUTPUT", "P", "PRE", "SECTION", "TABLE", "TBODY", "TD", "TFOOT", "TH", "THEAD", "TR", "UL"];
function isBlock(node) {
  return is(node, blockElements);
}
var voidElements = ["AREA", "BASE", "BR", "COL", "COMMAND", "EMBED", "HR", "IMG", "INPUT", "KEYGEN", "LINK", "META", "PARAM", "SOURCE", "TRACK", "WBR"];
function isVoid(node) {
  return is(node, voidElements);
}
function hasVoid(node) {
  return has(node, voidElements);
}
var meaningfulWhenBlankElements = ["A", "TABLE", "THEAD", "TBODY", "TFOOT", "TH", "TD", "IFRAME", "SCRIPT", "AUDIO", "VIDEO"];
function isMeaningfulWhenBlank(node) {
  return is(node, meaningfulWhenBlankElements);
}
function hasMeaningfulWhenBlank(node) {
  return has(node, meaningfulWhenBlankElements);
}
function is(node, tagNames) {
  return tagNames.indexOf(node.nodeName) >= 0;
}
function has(node, tagNames) {
  return node.getElementsByTagName && tagNames.some(function(tagName) {
    return node.getElementsByTagName(tagName).length;
  });
}
var markdownEscapes = [[/\\/g, "\\\\"], [/\*/g, "\\*"], [/^-/g, "\\-"], [/^\+ /g, "\\+ "], [/^(=+)/g, "\\$1"], [/^(#{1,6}) /g, "\\$1 "], [/`/g, "\\`"], [/^~~~/g, "\\~~~"], [/\[/g, "\\["], [/\]/g, "\\]"], [/^>/g, "\\>"], [/_/g, "\\_"], [/^(\d+)\. /g, "$1\\. "]];
function escapeMarkdown(string) {
  return markdownEscapes.reduce(function(accumulator, escape) {
    return accumulator.replace(escape[0], escape[1]);
  }, string);
}
var rules = {};
rules.paragraph = {
  filter: "p",
  replacement: function(content) {
    return "\n\n" + content + "\n\n";
  }
};
rules.lineBreak = {
  filter: "br",
  replacement: function(content, node, options) {
    return options.br + "\n";
  }
};
rules.heading = {
  filter: ["h1", "h2", "h3", "h4", "h5", "h6"],
  replacement: function(content, node, options) {
    var hLevel = Number(node.nodeName.charAt(1));
    if (options.headingStyle === "setext" && hLevel < 3) {
      var underline = repeat(hLevel === 1 ? "=" : "-", content.length);
      return "\n\n" + content + "\n" + underline + "\n\n";
    } else {
      return "\n\n" + repeat("#", hLevel) + " " + content + "\n\n";
    }
  }
};
rules.blockquote = {
  filter: "blockquote",
  replacement: function(content) {
    content = trimNewlines(content).replace(/^/gm, "> ");
    return "\n\n" + content + "\n\n";
  }
};
rules.list = {
  filter: ["ul", "ol"],
  replacement: function(content, node) {
    var parent = node.parentNode;
    if (parent.nodeName === "LI" && parent.lastElementChild === node) {
      return "\n" + content;
    } else {
      return "\n\n" + content + "\n\n";
    }
  }
};
rules.listItem = {
  filter: "li",
  replacement: function(content, node, options) {
    var prefix = options.bulletListMarker + "   ";
    var parent = node.parentNode;
    if (parent.nodeName === "OL") {
      var start = parent.getAttribute("start");
      var index = Array.prototype.indexOf.call(parent.children, node);
      prefix = (start ? Number(start) + index : index + 1) + ".  ";
    }
    var isParagraph = /\n$/.test(content);
    content = trimNewlines(content) + (isParagraph ? "\n" : "");
    content = content.replace(/\n/gm, "\n" + " ".repeat(prefix.length));
    return prefix + content + (node.nextSibling ? "\n" : "");
  }
};
rules.indentedCodeBlock = {
  filter: function(node, options) {
    return options.codeBlockStyle === "indented" && node.nodeName === "PRE" && node.firstChild && node.firstChild.nodeName === "CODE";
  },
  replacement: function(content, node, options) {
    return "\n\n    " + node.firstChild.textContent.replace(/\n/g, "\n    ") + "\n\n";
  }
};
rules.fencedCodeBlock = {
  filter: function(node, options) {
    return options.codeBlockStyle === "fenced" && node.nodeName === "PRE" && node.firstChild && node.firstChild.nodeName === "CODE";
  },
  replacement: function(content, node, options) {
    var className = node.firstChild.getAttribute("class") || "";
    var language = (className.match(/language-(\S+)/) || [null, ""])[1];
    var code = node.firstChild.textContent;
    var fenceChar = options.fence.charAt(0);
    var fenceSize = 3;
    var fenceInCodeRegex = new RegExp("^" + fenceChar + "{3,}", "gm");
    var match;
    while (match = fenceInCodeRegex.exec(code)) {
      if (match[0].length >= fenceSize) {
        fenceSize = match[0].length + 1;
      }
    }
    var fence = repeat(fenceChar, fenceSize);
    return "\n\n" + fence + language + "\n" + code.replace(/\n$/, "") + "\n" + fence + "\n\n";
  }
};
rules.horizontalRule = {
  filter: "hr",
  replacement: function(content, node, options) {
    return "\n\n" + options.hr + "\n\n";
  }
};
rules.inlineLink = {
  filter: function(node, options) {
    return options.linkStyle === "inlined" && node.nodeName === "A" && node.getAttribute("href");
  },
  replacement: function(content, node) {
    var href = escapeLinkDestination(node.getAttribute("href"));
    var title = escapeLinkTitle(cleanAttribute(node.getAttribute("title")));
    var titlePart = title ? ' "' + title + '"' : "";
    return "[" + content + "](" + href + titlePart + ")";
  }
};
rules.referenceLink = {
  filter: function(node, options) {
    return options.linkStyle === "referenced" && node.nodeName === "A" && node.getAttribute("href");
  },
  replacement: function(content, node, options) {
    var href = escapeLinkDestination(node.getAttribute("href"));
    var title = cleanAttribute(node.getAttribute("title"));
    if (title)
      title = ' "' + escapeLinkTitle(title) + '"';
    var replacement;
    var reference;
    switch (options.linkReferenceStyle) {
      case "collapsed":
        replacement = "[" + content + "][]";
        reference = "[" + content + "]: " + href + title;
        break;
      case "shortcut":
        replacement = "[" + content + "]";
        reference = "[" + content + "]: " + href + title;
        break;
      default:
        var id = this.references.length + 1;
        replacement = "[" + content + "][" + id + "]";
        reference = "[" + id + "]: " + href + title;
    }
    this.references.push(reference);
    return replacement;
  },
  references: [],
  append: function(options) {
    var references = "";
    if (this.references.length) {
      references = "\n\n" + this.references.join("\n") + "\n\n";
      this.references = [];
    }
    return references;
  }
};
rules.emphasis = {
  filter: ["em", "i"],
  replacement: function(content, node, options) {
    if (!content.trim())
      return "";
    return options.emDelimiter + content + options.emDelimiter;
  }
};
rules.strong = {
  filter: ["strong", "b"],
  replacement: function(content, node, options) {
    if (!content.trim())
      return "";
    return options.strongDelimiter + content + options.strongDelimiter;
  }
};
rules.code = {
  filter: function(node) {
    var hasSiblings = node.previousSibling || node.nextSibling;
    var isCodeBlock = node.parentNode.nodeName === "PRE" && !hasSiblings;
    return node.nodeName === "CODE" && !isCodeBlock;
  },
  replacement: function(content) {
    if (!content)
      return "";
    content = content.replace(/\r?\n|\r/g, " ");
    var extraSpace = /^`|^ .*?[^ ].* $|`$/.test(content) ? " " : "";
    var delimiter = "`";
    var matches = content.match(/`+/gm) || [];
    while (matches.indexOf(delimiter) !== -1)
      delimiter = delimiter + "`";
    return delimiter + extraSpace + content + extraSpace + delimiter;
  }
};
rules.image = {
  filter: "img",
  replacement: function(content, node) {
    var alt = escapeMarkdown(cleanAttribute(node.getAttribute("alt")));
    var src = escapeLinkDestination(node.getAttribute("src") || "");
    var title = cleanAttribute(node.getAttribute("title"));
    var titlePart = title ? ' "' + escapeLinkTitle(title) + '"' : "";
    return src ? "![" + alt + "](" + src + titlePart + ")" : "";
  }
};
function cleanAttribute(attribute) {
  return attribute ? attribute.replace(/(\n+\s*)+/g, "\n") : "";
}
function escapeLinkDestination(destination) {
  var escaped = destination.replace(/([<>()])/g, "\\$1");
  return escaped.indexOf(" ") >= 0 ? "<" + escaped + ">" : escaped;
}
function escapeLinkTitle(title) {
  return title.replace(/"/g, '\\"');
}
function Rules(options) {
  this.options = options;
  this._keep = [];
  this._remove = [];
  this.blankRule = {
    replacement: options.blankReplacement
  };
  this.keepReplacement = options.keepReplacement;
  this.defaultRule = {
    replacement: options.defaultReplacement
  };
  this.array = [];
  for (var key in options.rules)
    this.array.push(options.rules[key]);
}
Rules.prototype = {
  add: function(key, rule) {
    this.array.unshift(rule);
  },
  keep: function(filter) {
    this._keep.unshift({
      filter,
      replacement: this.keepReplacement
    });
  },
  remove: function(filter) {
    this._remove.unshift({
      filter,
      replacement: function() {
        return "";
      }
    });
  },
  forNode: function(node) {
    if (node.isBlank)
      return this.blankRule;
    var rule;
    if (rule = findRule(this.array, node, this.options))
      return rule;
    if (rule = findRule(this._keep, node, this.options))
      return rule;
    if (rule = findRule(this._remove, node, this.options))
      return rule;
    return this.defaultRule;
  },
  forEach: function(fn) {
    for (var i = 0; i < this.array.length; i++)
      fn(this.array[i], i);
  }
};
function findRule(rules3, node, options) {
  for (var i = 0; i < rules3.length; i++) {
    var rule = rules3[i];
    if (filterValue(rule, node, options))
      return rule;
  }
  return void 0;
}
function filterValue(rule, node, options) {
  var filter = rule.filter;
  if (typeof filter === "string") {
    if (filter === node.nodeName.toLowerCase())
      return true;
  } else if (Array.isArray(filter)) {
    if (filter.indexOf(node.nodeName.toLowerCase()) > -1)
      return true;
  } else if (typeof filter === "function") {
    if (filter.call(rule, node, options))
      return true;
  } else {
    throw new TypeError("`filter` needs to be a string, array, or function");
  }
}
function collapseWhitespace(options) {
  var element = options.element;
  var isBlock2 = options.isBlock;
  var isVoid2 = options.isVoid;
  var isPre = options.isPre || function(node2) {
    return node2.nodeName === "PRE";
  };
  if (!element.firstChild || isPre(element))
    return;
  var prevText = null;
  var keepLeadingWs = false;
  var prev = null;
  var node = next(prev, element, isPre);
  while (node !== element) {
    if (node.nodeType === 3 || node.nodeType === 4) {
      var text = node.data.replace(/[ \r\n\t]+/g, " ");
      if ((!prevText || / $/.test(prevText.data)) && !keepLeadingWs && text[0] === " ") {
        text = text.substr(1);
      }
      if (!text) {
        node = remove(node);
        continue;
      }
      node.data = text;
      prevText = node;
    } else if (node.nodeType === 1) {
      if (isBlock2(node) || node.nodeName === "BR") {
        if (prevText) {
          prevText.data = prevText.data.replace(/ $/, "");
        }
        prevText = null;
        keepLeadingWs = false;
      } else if (isVoid2(node) || isPre(node)) {
        prevText = null;
        keepLeadingWs = true;
      } else if (prevText) {
        keepLeadingWs = false;
      }
    } else {
      node = remove(node);
      continue;
    }
    var nextNode = next(prev, node, isPre);
    prev = node;
    node = nextNode;
  }
  if (prevText) {
    prevText.data = prevText.data.replace(/ $/, "");
    if (!prevText.data) {
      remove(prevText);
    }
  }
}
function remove(node) {
  var next2 = node.nextSibling || node.parentNode;
  node.parentNode.removeChild(node);
  return next2;
}
function next(prev, current, isPre) {
  if (prev && prev.parentNode === current || isPre(current)) {
    return current.nextSibling || current.parentNode;
  }
  return current.firstChild || current.nextSibling || current.parentNode;
}
var root = typeof window !== "undefined" ? window : {};
function canParseHTMLNatively() {
  var Parser = root.DOMParser;
  var canParse = false;
  try {
    if (new Parser().parseFromString("", "text/html")) {
      canParse = true;
    }
  } catch (e) {
  }
  return canParse;
}
function createHTMLParser() {
  var Parser = function() {
  };
  {
    if (shouldUseActiveX()) {
      Parser.prototype.parseFromString = function(string) {
        var doc = new window.ActiveXObject("htmlfile");
        doc.designMode = "on";
        doc.open();
        doc.write(string);
        doc.close();
        return doc;
      };
    } else {
      Parser.prototype.parseFromString = function(string) {
        var doc = document.implementation.createHTMLDocument("");
        doc.open();
        doc.write(string);
        doc.close();
        return doc;
      };
    }
  }
  return Parser;
}
function shouldUseActiveX() {
  var useActiveX = false;
  try {
    document.implementation.createHTMLDocument("").open();
  } catch (e) {
    if (root.ActiveXObject)
      useActiveX = true;
  }
  return useActiveX;
}
var HTMLParser = canParseHTMLNatively() ? root.DOMParser : createHTMLParser();
function RootNode(input, options) {
  var root2;
  if (typeof input === "string") {
    var doc = htmlParser().parseFromString(
      // DOM parsers arrange elements in the <head> and <body>.
      // Wrapping in a custom element ensures elements are reliably arranged in
      // a single element.
      '<x-turndown id="turndown-root">' + input + "</x-turndown>",
      "text/html"
    );
    root2 = doc.getElementById("turndown-root");
  } else {
    root2 = input.cloneNode(true);
  }
  collapseWhitespace({
    element: root2,
    isBlock,
    isVoid,
    isPre: options.preformattedCode ? isPreOrCode : null
  });
  return root2;
}
var _htmlParser;
function htmlParser() {
  _htmlParser = _htmlParser || new HTMLParser();
  return _htmlParser;
}
function isPreOrCode(node) {
  return node.nodeName === "PRE" || node.nodeName === "CODE";
}
function Node(node, options) {
  node.isBlock = isBlock(node);
  node.isCode = node.nodeName === "CODE" || node.parentNode.isCode;
  node.isBlank = isBlank(node);
  node.flankingWhitespace = flankingWhitespace(node, options);
  return node;
}
function isBlank(node) {
  return !isVoid(node) && !isMeaningfulWhenBlank(node) && /^\s*$/i.test(node.textContent) && !hasVoid(node) && !hasMeaningfulWhenBlank(node);
}
function flankingWhitespace(node, options) {
  if (node.isBlock || options.preformattedCode && node.isCode) {
    return {
      leading: "",
      trailing: ""
    };
  }
  var edges = edgeWhitespace(node.textContent);
  if (edges.leadingAscii && isFlankedByWhitespace("left", node, options)) {
    edges.leading = edges.leadingNonAscii;
  }
  if (edges.trailingAscii && isFlankedByWhitespace("right", node, options)) {
    edges.trailing = edges.trailingNonAscii;
  }
  return {
    leading: edges.leading,
    trailing: edges.trailing
  };
}
function edgeWhitespace(string) {
  var m = string.match(/^(([ \t\r\n]*)(\s*))(?:(?=\S)[\s\S]*\S)?((\s*?)([ \t\r\n]*))$/);
  return {
    leading: m[1],
    // whole string for whitespace-only strings
    leadingAscii: m[2],
    leadingNonAscii: m[3],
    trailing: m[4],
    // empty for whitespace-only strings
    trailingNonAscii: m[5],
    trailingAscii: m[6]
  };
}
function isFlankedByWhitespace(side, node, options) {
  var sibling;
  var regExp;
  var isFlanked;
  if (side === "left") {
    sibling = node.previousSibling;
    regExp = / $/;
  } else {
    sibling = node.nextSibling;
    regExp = /^ /;
  }
  if (sibling) {
    if (sibling.nodeType === 3) {
      isFlanked = regExp.test(sibling.nodeValue);
    } else if (options.preformattedCode && sibling.nodeName === "CODE") {
      isFlanked = false;
    } else if (sibling.nodeType === 1 && !isBlock(sibling)) {
      isFlanked = regExp.test(sibling.textContent);
    }
  }
  return isFlanked;
}
var reduce = Array.prototype.reduce;
function TurndownService(options) {
  if (!(this instanceof TurndownService))
    return new TurndownService(options);
  var defaults = {
    rules,
    headingStyle: "setext",
    hr: "* * *",
    bulletListMarker: "*",
    codeBlockStyle: "indented",
    fence: "```",
    emDelimiter: "_",
    strongDelimiter: "**",
    linkStyle: "inlined",
    linkReferenceStyle: "full",
    br: "  ",
    preformattedCode: false,
    blankReplacement: function(content, node) {
      return node.isBlock ? "\n\n" : "";
    },
    keepReplacement: function(content, node) {
      return node.isBlock ? "\n\n" + node.outerHTML + "\n\n" : node.outerHTML;
    },
    defaultReplacement: function(content, node) {
      return node.isBlock ? "\n\n" + content + "\n\n" : content;
    }
  };
  this.options = extend({}, defaults, options);
  this.rules = new Rules(this.options);
}
TurndownService.prototype = {
  /**
   * The entry point for converting a string or DOM node to Markdown
   * @public
   * @param {String|HTMLElement} input The string or DOM node to convert
   * @returns A Markdown representation of the input
   * @type String
   */
  turndown: function(input) {
    if (!canConvert(input)) {
      throw new TypeError(input + " is not a string, or an element/document/fragment node.");
    }
    if (input === "")
      return "";
    var output = process2.call(this, new RootNode(input, this.options));
    return postProcess.call(this, output);
  },
  /**
   * Add one or more plugins
   * @public
   * @param {Function|Array} plugin The plugin or array of plugins to add
   * @returns The Turndown instance for chaining
   * @type Object
   */
  use: function(plugin) {
    if (Array.isArray(plugin)) {
      for (var i = 0; i < plugin.length; i++)
        this.use(plugin[i]);
    } else if (typeof plugin === "function") {
      plugin(this);
    } else {
      throw new TypeError("plugin must be a Function or an Array of Functions");
    }
    return this;
  },
  /**
   * Adds a rule
   * @public
   * @param {String} key The unique key of the rule
   * @param {Object} rule The rule
   * @returns The Turndown instance for chaining
   * @type Object
   */
  addRule: function(key, rule) {
    this.rules.add(key, rule);
    return this;
  },
  /**
   * Keep a node (as HTML) that matches the filter
   * @public
   * @param {String|Array|Function} filter The unique key of the rule
   * @returns The Turndown instance for chaining
   * @type Object
   */
  keep: function(filter) {
    this.rules.keep(filter);
    return this;
  },
  /**
   * Remove a node that matches the filter
   * @public
   * @param {String|Array|Function} filter The unique key of the rule
   * @returns The Turndown instance for chaining
   * @type Object
   */
  remove: function(filter) {
    this.rules.remove(filter);
    return this;
  },
  /**
   * Escapes Markdown syntax
   * @public
   * @param {String} string The string to escape
   * @returns A string with Markdown syntax escaped
   * @type String
   */
  escape: function(string) {
    return escapeMarkdown(string);
  }
};
function process2(parentNode) {
  var self = this;
  return reduce.call(parentNode.childNodes, function(output, node) {
    node = new Node(node, self.options);
    var replacement = "";
    if (node.nodeType === 3) {
      replacement = node.isCode ? node.nodeValue : self.escape(node.nodeValue);
    } else if (node.nodeType === 1) {
      replacement = replacementForNode.call(self, node);
    }
    return join(output, replacement);
  }, "");
}
function postProcess(output) {
  var self = this;
  this.rules.forEach(function(rule) {
    if (typeof rule.append === "function") {
      output = join(output, rule.append(self.options));
    }
  });
  return output.replace(/^[\t\r\n]+/, "").replace(/[\t\r\n\s]+$/, "");
}
function replacementForNode(node) {
  var rule = this.rules.forNode(node);
  var content = process2.call(this, node);
  var whitespace = node.flankingWhitespace;
  if (whitespace.leading || whitespace.trailing)
    content = content.trim();
  return whitespace.leading + rule.replacement(content, node, this.options) + whitespace.trailing;
}
function join(output, replacement) {
  var s1 = trimTrailingNewlines(output);
  var s2 = trimLeadingNewlines(replacement);
  var nls = Math.max(output.length - s1.length, replacement.length - s2.length);
  var separator = "\n\n".substring(0, nls);
  return s1 + separator + s2;
}
function canConvert(input) {
  return input != null && (typeof input === "string" || input.nodeType && (input.nodeType === 1 || input.nodeType === 9 || input.nodeType === 11));
}

// node_modules/turndown-plugin-gfm/lib/turndown-plugin-gfm.es.js
var highlightRegExp = /highlight-(?:text|source)-([a-z0-9]+)/;
function highlightedCodeBlock(turndownService) {
  turndownService.addRule("highlightedCodeBlock", {
    filter: function(node) {
      var firstChild = node.firstChild;
      return node.nodeName === "DIV" && highlightRegExp.test(node.className) && firstChild && firstChild.nodeName === "PRE";
    },
    replacement: function(content, node, options) {
      var className = node.className || "";
      var language = (className.match(highlightRegExp) || [null, ""])[1];
      return "\n\n" + options.fence + language + "\n" + node.firstChild.textContent + "\n" + options.fence + "\n\n";
    }
  });
}
function strikethrough(turndownService) {
  turndownService.addRule("strikethrough", {
    filter: ["del", "s", "strike"],
    replacement: function(content) {
      return "~" + content + "~";
    }
  });
}
var indexOf = Array.prototype.indexOf;
var every = Array.prototype.every;
var rules2 = {};
rules2.tableCell = {
  filter: ["th", "td"],
  replacement: function(content, node) {
    return cell(content, node);
  }
};
rules2.tableRow = {
  filter: "tr",
  replacement: function(content, node) {
    var borderCells = "";
    var alignMap = { left: ":--", right: "--:", center: ":-:" };
    if (isHeadingRow(node)) {
      for (var i = 0; i < node.childNodes.length; i++) {
        var border = "---";
        var align = (node.childNodes[i].getAttribute("align") || "").toLowerCase();
        if (align)
          border = alignMap[align] || border;
        borderCells += cell(border, node.childNodes[i]);
      }
    }
    return "\n" + content + (borderCells ? "\n" + borderCells : "");
  }
};
rules2.table = {
  // Only convert tables with a heading row.
  // Tables with no heading row are kept using `keep` (see below).
  filter: function(node) {
    return node.nodeName === "TABLE" && isHeadingRow(node.rows[0]);
  },
  replacement: function(content) {
    content = content.replace("\n\n", "\n");
    return "\n\n" + content + "\n\n";
  }
};
rules2.tableSection = {
  filter: ["thead", "tbody", "tfoot"],
  replacement: function(content) {
    return content;
  }
};
function isHeadingRow(tr) {
  var parentNode = tr.parentNode;
  return parentNode.nodeName === "THEAD" || parentNode.firstChild === tr && (parentNode.nodeName === "TABLE" || isFirstTbody(parentNode)) && every.call(tr.childNodes, function(n) {
    return n.nodeName === "TH";
  });
}
function isFirstTbody(element) {
  var previousSibling = element.previousSibling;
  return element.nodeName === "TBODY" && (!previousSibling || previousSibling.nodeName === "THEAD" && /^\s*$/i.test(previousSibling.textContent));
}
function cell(content, node) {
  var index = indexOf.call(node.parentNode.childNodes, node);
  var prefix = " ";
  if (index === 0)
    prefix = "| ";
  return prefix + content + " |";
}
function tables(turndownService) {
  turndownService.keep(function(node) {
    return node.nodeName === "TABLE" && !isHeadingRow(node.rows[0]);
  });
  for (var key in rules2)
    turndownService.addRule(key, rules2[key]);
}
function taskListItems(turndownService) {
  turndownService.addRule("taskListItems", {
    filter: function(node) {
      return node.type === "checkbox" && node.parentNode.nodeName === "LI";
    },
    replacement: function(content, node) {
      return (node.checked ? "[x]" : "[ ]") + " ";
    }
  });
}
function gfm(turndownService) {
  turndownService.use([
    highlightedCodeBlock,
    strikethrough,
    tables,
    taskListItems
  ]);
}

// src/confluence/converter.ts
var XML_WRAPPER_OPEN = '<root xmlns:ac="http://atlassian.com/content" xmlns:ri="http://atlassian.com/resource/identifier">';
var XML_WRAPPER_CLOSE = "</root>";
function xhtmlToMarkdown(xhtml, opts) {
  const html = xmlToHtml(xhtml, opts);
  logger.debug("Intermediate HTML (first 500):", html.slice(0, 500));
  const td = buildTurndown();
  const md = td.turndown(html);
  return postprocess(md);
}
function xmlToHtml(xhtml, opts) {
  const sanitized = replaceHtmlEntities(xhtml);
  const wrapped = XML_WRAPPER_OPEN + sanitized + XML_WRAPPER_CLOSE;
  const parser = new DOMParser();
  const xmlDoc = parser.parseFromString(wrapped, "application/xml");
  const err = xmlDoc.querySelector("parsererror");
  if (err) {
    logger.warn("XML parse error in storage XHTML; output may be degraded.", err.textContent);
    return xhtml;
  }
  const root2 = xmlDoc.documentElement;
  let out = "";
  for (let i = 0; i < root2.childNodes.length; i++) {
    out += nodeToHtml(root2.childNodes[i], opts);
  }
  return out;
}
function replaceHtmlEntities(s) {
  return s.replace(/&([a-zA-Z][a-zA-Z0-9]+);/g, (full, name) => {
    if (name === "amp" || name === "lt" || name === "gt" || name === "quot" || name === "apos") {
      return full;
    }
    const ch = HTML_ENTITIES[name];
    return ch !== void 0 ? ch : full;
  });
}
var HTML_ENTITIES = {
  nbsp: "\xA0",
  copy: "\xA9",
  reg: "\xAE",
  trade: "\u2122",
  hellip: "\u2026",
  mdash: "\u2014",
  ndash: "\u2013",
  lsquo: "\u2018",
  rsquo: "\u2019",
  ldquo: "\u201C",
  rdquo: "\u201D",
  laquo: "\xAB",
  raquo: "\xBB",
  bull: "\u2022",
  middot: "\xB7",
  deg: "\xB0",
  plusmn: "\xB1",
  times: "\xD7",
  divide: "\xF7",
  larr: "\u2190",
  rarr: "\u2192",
  uarr: "\u2191",
  darr: "\u2193",
  harr: "\u2194",
  lArr: "\u21D0",
  rArr: "\u21D2",
  uArr: "\u21D1",
  dArr: "\u21D3",
  iexcl: "\xA1",
  iquest: "\xBF",
  sect: "\xA7",
  para: "\xB6",
  acute: "\xB4",
  cedil: "\xB8",
  sup1: "\xB9",
  sup2: "\xB2",
  sup3: "\xB3",
  frac14: "\xBC",
  frac12: "\xBD",
  frac34: "\xBE",
  Auml: "\xC4",
  Ouml: "\xD6",
  Uuml: "\xDC",
  auml: "\xE4",
  ouml: "\xF6",
  uuml: "\xFC",
  szlig: "\xDF",
  euro: "\u20AC",
  pound: "\xA3",
  yen: "\xA5",
  cent: "\xA2",
  check: "\u2713",
  cross: "\u2717",
  ensp: "\u2002",
  emsp: "\u2003",
  thinsp: "\u2009",
  zwnj: "\u200C",
  zwj: "\u200D"
};
function localName(el) {
  return (el.localName || el.tagName).toLowerCase();
}
function prefixOf(el) {
  const tag = el.tagName;
  const idx = tag.indexOf(":");
  return idx > 0 ? tag.slice(0, idx).toLowerCase() : "";
}
function getAttrNs(el, attrLocalName, prefixName) {
  const full = `${prefixName}:${attrLocalName}`;
  if (el.hasAttribute(full))
    return el.getAttribute(full);
  if (el.hasAttribute(attrLocalName))
    return el.getAttribute(attrLocalName);
  const nsMap = {
    ac: "http://atlassian.com/content",
    ri: "http://atlassian.com/resource/identifier"
  };
  const ns = nsMap[prefixName];
  if (ns) {
    const v = el.getAttributeNS(ns, attrLocalName);
    if (v !== null)
      return v;
  }
  return null;
}
function firstChildByPrefixLocal(el, pfx, local) {
  for (let i = 0; i < el.childNodes.length; i++) {
    const c = el.childNodes[i];
    if (c.nodeType !== 1)
      continue;
    const e = c;
    if (prefixOf(e) === pfx && localName(e) === local)
      return e;
  }
  return null;
}
function nodeToHtml(node, opts) {
  if (node.nodeType === 3)
    return escapeHtml(node.nodeValue ?? "");
  if (node.nodeType === 4)
    return escapeHtml(node.data);
  if (node.nodeType !== 1)
    return "";
  const el = node;
  const pfx = prefixOf(el);
  const local = localName(el);
  if (pfx === "ac")
    return acElementToHtml(el, local, opts);
  if (pfx === "ri")
    return "";
  if (local === "p") {
    const cls = el.getAttribute("class") || "";
    if (cls.split(/\s+/).includes("auto-cursor-target"))
      return "";
    if (isEffectivelyEmptyParagraph(el))
      return "";
  }
  if (local === "span")
    return childrenToHtml(el, opts);
  if (local === "br")
    return "<br>";
  const tag = local;
  const attrs = serializeAttrs(el, tag);
  if (VOID_ELEMENTS.has(tag))
    return `<${tag}${attrs}>`;
  return `<${tag}${attrs}>${childrenToHtml(el, opts)}</${tag}>`;
}
function childrenToHtml(el, opts) {
  let out = "";
  for (let i = 0; i < el.childNodes.length; i++) {
    out += nodeToHtml(el.childNodes[i], opts);
  }
  return out;
}
var VOID_ELEMENTS = /* @__PURE__ */ new Set([
  "area",
  "base",
  "br",
  "col",
  "embed",
  "hr",
  "img",
  "input",
  "link",
  "meta",
  "source",
  "track",
  "wbr"
]);
var ATTR_WHITELIST = {
  a: /* @__PURE__ */ new Set(["href", "title"]),
  img: /* @__PURE__ */ new Set(["src", "alt", "title", "width", "height"]),
  code: /* @__PURE__ */ new Set(["class"]),
  pre: /* @__PURE__ */ new Set([]),
  th: /* @__PURE__ */ new Set(["align", "colspan", "rowspan"]),
  td: /* @__PURE__ */ new Set(["align", "colspan", "rowspan"])
};
function serializeAttrs(el, tag) {
  const allow = ATTR_WHITELIST[tag] ?? /* @__PURE__ */ new Set();
  let out = "";
  for (let i = 0; i < el.attributes.length; i++) {
    const a = el.attributes[i];
    const n = a.name.toLowerCase();
    if (!allow.has(n))
      continue;
    out += ` ${n}="${escapeAttr(a.value)}"`;
  }
  return out;
}
function isEffectivelyEmptyParagraph(el) {
  for (let i = 0; i < el.childNodes.length; i++) {
    const c = el.childNodes[i];
    if (c.nodeType === 3) {
      if ((c.textContent || "").trim().length > 0)
        return false;
    } else if (c.nodeType === 1) {
      if (localName(c) !== "br")
        return false;
    }
  }
  return true;
}
function acElementToHtml(el, local, opts) {
  if (local === "image")
    return buildImageHtml(el, opts);
  if (local === "link")
    return buildLinkHtml(el, opts);
  if (local === "structured-macro")
    return buildMacroHtml(el, opts);
  if (local === "inline-comment-marker")
    return childrenToHtml(el, opts);
  if (local === "emoticon") {
    const name = getAttrNs(el, "name", "ac") || "";
    return escapeHtml(emoticonText(name));
  }
  return childrenToHtml(el, opts);
}
function buildImageHtml(el, opts) {
  const attach = firstChildByPrefixLocal(el, "ri", "attachment");
  if (attach) {
    const filename = getAttrNs(attach, "filename", "ri") || "";
    if (opts.linkStyle === "markdown") {
      const href = buildAttachmentHref(opts.attachmentHrefBase ?? opts.titleFolder, filename);
      return `<img src="${escapeAttr(href)}" alt="${escapeAttr(filename)}">`;
    }
    const target = buildWikilinkTarget(opts.titleFolder, filename);
    return `<img data-wikilink="${escapeAttr(target)}" alt="${escapeAttr(filename)}">`;
  }
  const urlEl = firstChildByPrefixLocal(el, "ri", "url");
  if (urlEl) {
    const href = getAttrNs(urlEl, "value", "ri") || "";
    return `<img src="${escapeAttr(href)}" alt="">`;
  }
  return "";
}
function buildLinkHtml(el, opts) {
  const attach = firstChildByPrefixLocal(el, "ri", "attachment");
  const page = firstChildByPrefixLocal(el, "ri", "page");
  const urlEl = firstChildByPrefixLocal(el, "ri", "url");
  const bodyEl = firstChildByPrefixLocal(el, "ac", "link-body") || firstChildByPrefixLocal(el, "ac", "plain-text-link-body");
  let href = "";
  let fallback = "";
  let wikilinkTarget = null;
  if (attach) {
    const filename = getAttrNs(attach, "filename", "ri") || "";
    if (opts.linkStyle === "markdown") {
      href = buildAttachmentHref(opts.attachmentHrefBase ?? opts.titleFolder, filename);
    } else {
      wikilinkTarget = buildWikilinkTarget(opts.titleFolder, filename);
    }
    fallback = stripExtension(filename);
  } else if (page) {
    const title = getAttrNs(page, "content-title", "ri") || "";
    const spaceKey = getAttrNs(page, "space-key", "ri") || "";
    const base = opts.baseUrl.replace(/\/+$/, "");
    href = spaceKey && title ? `${base}/display/${encodeURIComponent(spaceKey)}/${encodeURIComponent(title)}` : `${base}/dosearchsite.action?queryString=${encodeURIComponent(title)}`;
    fallback = title || href;
  } else if (urlEl) {
    href = getAttrNs(urlEl, "value", "ri") || "";
    fallback = href;
  } else {
    return "";
  }
  const body = bodyEl && bodyEl.childNodes.length > 0 ? childrenToHtml(bodyEl, opts) : escapeHtml(fallback);
  if (wikilinkTarget !== null) {
    return `<a data-wikilink="${escapeAttr(wikilinkTarget)}">${body}</a>`;
  }
  return `<a href="${escapeAttr(href)}">${body}</a>`;
}
function buildMacroHtml(el, opts) {
  const name = (getAttrNs(el, "name", "ac") || "").toLowerCase();
  if (name === "toc")
    return "";
  if (name === "code") {
    const lang = getParam(el, "language") || "";
    const title = getParam(el, "title") || "";
    const body = getPlainTextBody(el);
    const titleHtml = title ? `<p><strong>${escapeHtml(title)}</strong></p>` : "";
    const cls = lang ? ` class="language-${escapeAttr(lang)}"` : "";
    return `${titleHtml}<pre><code${cls}>${escapeHtml(body)}</code></pre>`;
  }
  if (name === "info" || name === "note" || name === "warning" || name === "tip") {
    const rich2 = firstChildByPrefixLocal(el, "ac", "rich-text-body");
    const inner = rich2 ? childrenToHtml(rich2, opts) : "";
    return `<blockquote><p>[!${name}]</p>${inner}</blockquote>`;
  }
  if (name === "noformat") {
    const body = getPlainTextBody(el);
    return `<pre><code>${escapeHtml(body)}</code></pre>`;
  }
  if (name === "status") {
    const title = getParam(el, "title") || "";
    return `<strong>${escapeHtml(title)}</strong>`;
  }
  const rich = firstChildByPrefixLocal(el, "ac", "rich-text-body");
  if (rich)
    return childrenToHtml(rich, opts);
  return "";
}
function getParam(macro, name) {
  for (let i = 0; i < macro.childNodes.length; i++) {
    const c = macro.childNodes[i];
    if (c.nodeType !== 1)
      continue;
    const e = c;
    if (prefixOf(e) === "ac" && localName(e) === "parameter") {
      if (getAttrNs(e, "name", "ac") === name)
        return e.textContent ?? "";
    }
  }
  return null;
}
function getPlainTextBody(macro) {
  const body = firstChildByPrefixLocal(macro, "ac", "plain-text-body");
  if (!body)
    return "";
  return body.textContent ?? "";
}
function buildAttachmentHref(folder, filename) {
  const encodedFolder = folder.split("/").filter((s) => s.length > 0).map(encodeURIComponent).join("/");
  const encodedName = encodeURIComponent(filename);
  return encodedFolder ? `${encodedFolder}/${encodedName}` : encodedName;
}
function buildWikilinkTarget(titleFolder, filename) {
  const clean = (s) => s.replace(/[\[\]|#]/g, "_");
  return `${clean(titleFolder)}/${clean(filename)}`;
}
function stripExtension(filename) {
  const i = filename.lastIndexOf(".");
  if (i <= 0)
    return filename;
  return filename.slice(0, i);
}
function emoticonText(name) {
  const map = {
    smile: "\u{1F642}",
    sad: "\u{1F641}",
    wink: "\u{1F609}",
    laugh: "\u{1F604}",
    tongue: "\u{1F61B}",
    cheeky: "\u{1F61C}",
    thumbs_up: "\u{1F44D}",
    thumbs_down: "\u{1F44E}",
    information: "\u2139\uFE0F",
    tick: "\u2705",
    cross: "\u274C",
    warning: "\u26A0\uFE0F"
  };
  return map[name] ?? "";
}
function escapeHtml(s) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function escapeAttr(s) {
  return s.replace(/&/g, "&amp;").replace(/"/g, "&quot;");
}
function buildTurndown() {
  const td = new TurndownService({
    headingStyle: "atx",
    codeBlockStyle: "fenced",
    bulletListMarker: "-",
    emDelimiter: "*"
  });
  td.use(gfm);
  td.addRule("wikilinkEmbed", {
    filter: (node) => node.nodeName === "IMG" && node.hasAttribute("data-wikilink"),
    replacement: (_content, node) => {
      const target = node.getAttribute("data-wikilink") || "";
      return `![[${target}]]`;
    }
  });
  td.addRule("wikilinkAnchor", {
    filter: (node) => node.nodeName === "A" && node.hasAttribute("data-wikilink"),
    replacement: (content, node) => {
      const target = node.getAttribute("data-wikilink") || "";
      const text = (content || "").trim();
      if (!text)
        return `[[${target}]]`;
      return `[[${target}|${text}]]`;
    }
  });
  td.addRule("fencedCodeLang", {
    filter: (node) => node.nodeName === "PRE" && node.firstChild != null && node.firstChild.nodeName === "CODE",
    replacement: (_content, node) => {
      const code = node.firstChild;
      const cls = code.getAttribute("class") || "";
      const m = cls.match(/language-(\S+)/);
      const lang = m ? m[1] : "";
      const text = code.textContent ?? "";
      return "\n\n```" + lang + "\n" + text.replace(/\n$/, "") + "\n```\n\n";
    }
  });
  return td;
}
function postprocess(md) {
  let out = md;
  out = out.replace(/\n{3,}/g, "\n\n");
  return out.trim() + "\n";
}

// src/utils/url.ts
function parsePageId(input) {
  if (!input)
    return null;
  const raw = input.trim();
  if (raw.length === 0)
    return null;
  if (/^\d{6,12}$/.test(raw))
    return raw;
  let url;
  try {
    url = new URL(raw);
  } catch {
    return null;
  }
  const pageIdParam = url.searchParams.get("pageId");
  if (pageIdParam && /^\d{3,}$/.test(pageIdParam)) {
    return pageIdParam;
  }
  const m = url.pathname.match(/\/pages\/(\d{3,})(?:\/|$)/);
  if (m)
    return m[1];
  return null;
}
function isTinyUiLink(input) {
  try {
    const u = new URL(input.trim());
    return /\/x\/[A-Za-z0-9_-]+/.test(u.pathname);
  } catch {
    return false;
  }
}

// src/utils/filename.ts
function sanitizeFilename(name) {
  if (!name)
    return "untitled";
  const cleaned = name.replace(/[<>:"/\\|?*\x00-\x1F]/g, "_").replace(/\s+/g, " ").replace(/[. ]+$/g, "").trim();
  return cleaned.length > 0 ? cleaned : "untitled";
}
function joinVaultPath(...segments) {
  return segments.map((s) => s.replace(/^\/+|\/+$/g, "")).filter((s) => s.length > 0).join("/");
}

// src/confluence/pipeline.ts
var Pipeline = class {
  constructor(app, settings) {
    this.app = app;
    this.settings = settings;
    this.client = new ConfluenceClient(settings);
  }
  async downloadByInput(input) {
    const pageId = parsePageId(input);
    if (!pageId) {
      if (isTinyUiLink(input)) {
        throw new Error("Short links (/x/...) are not supported. Please paste the full page URL.");
      }
      throw new Error("Invalid input: expect a wiki URL or numeric pageId.");
    }
    return this.downloadByPageId(pageId);
  }
  async downloadByPageId(pageId) {
    logger.info("Fetching page", pageId);
    new import_obsidian3.Notice(`Fetching page ${pageId}\u2026`);
    const page = await this.client.getPage(pageId);
    logger.info("Page", page.id, page.title, `v${page.version}`);
    const attachments = await this.client.listAttachments(pageId);
    logger.info("Attachments listed:", attachments.length);
    const titleFolder = sanitizeFilename(page.title);
    const inbox = (this.settings.inboxPath || "inbox").replace(/^\/+|\/+$/g, "");
    const folderPath = (0, import_obsidian3.normalizePath)(joinVaultPath(inbox, titleFolder));
    const mdBase = this.settings.filenameSource === "pageId" ? pageId : titleFolder;
    const mdPath = (0, import_obsidian3.normalizePath)(joinVaultPath(inbox, `${mdBase}.md`));
    await this.ensureFolder(inbox);
    const referenced = extractReferencedFilenames(page.storageXhtml);
    const toDownload = this.settings.downloadAllAttachments ? attachments : attachments.filter((a) => {
      const urlName = filenameFromDownloadPath(a.downloadPath);
      return urlName && referenced.has(urlName) || referenced.has(a.title);
    });
    let downloaded = 0;
    const failed = [];
    if (toDownload.length > 0) {
      await this.ensureFolder(folderPath);
      new import_obsidian3.Notice(`Downloading ${toDownload.length} attachments\u2026`);
      const results = await runWithConcurrency(toDownload, HARDCODED.concurrency, async (a) => {
        try {
          await this.downloadOne(a, folderPath);
          return { ok: true, name: a.title };
        } catch (e) {
          logger.warn("Attachment failed", a.title, e.message);
          return { ok: false, name: a.title };
        }
      });
      for (const r of results)
        r.ok ? downloaded++ : failed.push(r.name);
    }
    const attachmentFilenames = new Set(attachments.map((a) => a.title));
    const markdownBody = xhtmlToMarkdown(page.storageXhtml, {
      titleFolder: folderPath,
      baseUrl: this.settings.baseUrl,
      attachmentFilenames,
      linkStyle: this.settings.linkStyle,
      // Standard-markdown hrefs must be relative to the MD file, which sits in
      // the same parent as the attachment folder, so just the title is enough.
      attachmentHrefBase: titleFolder
    });
    const frontmatter = this.settings.writeFrontmatter ? buildFrontmatter(page) : "";
    const fullMd = frontmatter + markdownBody;
    await this.writeMarkdown(mdPath, fullMd);
    const msg = failed.length ? `Done with ${failed.length} attachment failures. See console for details.` : `Done. Downloaded ${downloaded} attachments.`;
    new import_obsidian3.Notice(msg);
    logger.info("Result", { mdPath, downloaded, failed });
    return { markdownPath: mdPath, attachmentCount: downloaded, failedAttachments: failed };
  }
  async downloadOne(a, folderPath) {
    if (!a.downloadPath)
      throw new Error(`No download URL for ${a.title}`);
    const buf = await this.client.downloadAttachment(a.downloadPath);
    const nameFromUrl = filenameFromDownloadPath(a.downloadPath);
    const safeName = sanitizeFilename(nameFromUrl || a.title);
    const filePath = (0, import_obsidian3.normalizePath)(joinVaultPath(folderPath, safeName));
    await this.writeBinary(filePath, buf);
    logger.debug("Saved", filePath, `${buf.byteLength} bytes`);
  }
  async ensureFolder(path) {
    const v = this.app.vault;
    if (!path)
      return;
    const exists = v.getAbstractFileByPath(path);
    if (exists)
      return;
    try {
      await v.createFolder(path);
    } catch (e) {
      if (!v.getAbstractFileByPath(path))
        throw e;
    }
  }
  async writeBinary(path, data) {
    const v = this.app.vault;
    const existing = v.getAbstractFileByPath(path);
    if (existing && "stat" in existing) {
      await v.modifyBinary(existing, data);
      return;
    }
    await v.createBinary(path, data);
  }
  async writeMarkdown(path, content) {
    const v = this.app.vault;
    const existing = v.getAbstractFileByPath(path);
    if (existing) {
      if (!this.settings.overwriteExisting) {
        throw new Error(
          `File exists: ${path}. Enable "Overwrite existing files" in settings to replace it.`
        );
      }
      await v.modify(existing, content);
      return;
    }
    await v.create(path, content);
  }
};
function buildFrontmatter(page) {
  const now = /* @__PURE__ */ new Date();
  const esc = (s) => s.replace(/"/g, '\\"');
  const lines = [
    "---",
    `source: "${esc(page.webUrl)}"`,
    `pageId: "${page.id}"`,
    `spaceKey: "${esc(page.spaceKey)}"`,
    `version: ${page.version}`,
    `originalTitle: "${esc(page.title)}"`
  ];
  if (page.createdBy)
    lines.push(`createdBy: "${esc(page.createdBy)}"`);
  if (page.createdAt)
    lines.push(`createdAt: "${esc(page.createdAt)}"`);
  if (page.lastModifiedBy)
    lines.push(`lastModifiedBy: "${esc(page.lastModifiedBy)}"`);
  if (page.lastModifiedAt)
    lines.push(`lastModifiedAt: "${esc(page.lastModifiedAt)}"`);
  lines.push(`fetchedAt: "${now.toISOString()}"`, "---", "");
  return lines.join("\n");
}
function extractReferencedFilenames(xhtml) {
  const out = /* @__PURE__ */ new Set();
  const re = /ri:filename="([^"]+)"/g;
  let m;
  while (m = re.exec(xhtml))
    out.add(m[1]);
  return out;
}
function filenameFromDownloadPath(p) {
  if (!p)
    return "";
  const noQuery = p.split(/[?#]/, 1)[0];
  const seg = noQuery.split("/").pop() || "";
  try {
    return decodeURIComponent(seg);
  } catch {
    return seg;
  }
}
async function runWithConcurrency(items, concurrency, fn) {
  const results = new Array(items.length);
  let next2 = 0;
  async function worker() {
    while (true) {
      const i = next2++;
      if (i >= items.length)
        return;
      results[i] = await fn(items[i], i);
    }
  }
  const n = Math.min(Math.max(concurrency, 1), items.length);
  await Promise.all(Array.from({ length: n }, () => worker()));
  return results;
}

// src/ui/UrlModal.ts
var import_obsidian4 = require("obsidian");
var UrlModal = class extends import_obsidian4.Modal {
  constructor(app, onSubmit) {
    super(app);
    this.onSubmit = onSubmit;
    this.value = "";
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.empty();
    contentEl.createEl("h2", { text: "Download Axera wiki page" });
    const field = contentEl.createDiv({ cls: "axwc-field" });
    field.createEl("div", { text: "URL or page ID", cls: "setting-item-name" });
    const desc = field.createEl("div", {
      text: "Paste a wiki page URL, or just the numeric pageId (e.g. 242053973).",
      cls: "setting-item-description"
    });
    desc.style.whiteSpace = "nowrap";
    desc.style.overflow = "hidden";
    desc.style.textOverflow = "ellipsis";
    const input = field.createEl("input", { type: "text", cls: "axwc-url-input" });
    input.placeholder = "https://wiki.aixin-chip.com/pages/viewpage.action?pageId=242053973";
    input.style.width = "100%";
    input.style.marginTop = "8px";
    input.addEventListener("input", () => this.value = input.value);
    input.addEventListener("keydown", (ev) => {
      if (ev.key === "Enter") {
        ev.preventDefault();
        this.submit();
      }
    });
    setTimeout(() => input.focus(), 0);
    new import_obsidian4.Setting(contentEl).addButton(
      (b) => b.setButtonText("Cancel").onClick(() => this.close())
    ).addButton(
      (b) => b.setButtonText("Download").setCta().onClick(() => this.submit())
    );
  }
  submit() {
    const v = this.value.trim();
    if (!v)
      return;
    this.close();
    this.onSubmit(v);
  }
  onClose() {
    this.contentEl.empty();
  }
};

// main.ts
var AXERA_WIKI_ICON_SVG = '<g transform="translate(0,100) scale(0.0526316,-0.0526316)" fill="currentColor" stroke="none"><path d="M1398 1798 c-9 -7 -37 -47 -63 -88 -52 -83 -116 -154 -158 -176 -44 -23 -112 -32 -169 -22 -77 13 -169 50 -387 156 -257 123 -259 124 -282 112 -23 -13 -35 -36 -133 -258 -49 -110 -76 -183 -74 -200 3 -23 17 -34 108 -79 217 -108 419 -197 532 -234 217 -71 421 -73 589 -4 152 61 290 189 418 385 83 126 87 135 72 158 -12 19 -403 262 -422 262 -8 0 -22 -6 -31 -12z"/><path d="M660 921 c-203 -46 -372 -180 -525 -415 -72 -110 -79 -124 -76 -157 1 -9 86 -69 206 -143 162 -101 211 -127 230 -122 15 4 35 26 55 61 84 146 150 209 249 235 35 9 57 8 117 -5 93 -21 141 -40 399 -164 115 -56 222 -101 237 -101 18 0 33 8 43 23 35 54 186 413 183 437 -3 27 -43 50 -303 172 -391 183 -598 229 -815 179z"/></g>';
var AxWikiClipperPlugin = class extends import_obsidian5.Plugin {
  constructor() {
    super(...arguments);
    this.settings = DEFAULT_SETTINGS;
  }
  async onload() {
    await this.loadSettings();
    logger.info("onload");
    (0, import_obsidian5.addIcon)("axera-wiki", AXERA_WIKI_ICON_SVG);
    this.addRibbonIcon("axera-wiki", "AxeraWikiClipper: Download wiki page", () => {
      this.openDownloadModal();
    });
    this.addCommand({
      id: "download-wiki",
      name: "Download wiki page by URL",
      callback: () => this.openDownloadModal()
    });
    this.addSettingTab(new AxWikiClipperSettingTab(this.app, this));
  }
  onunload() {
    logger.info("onunload");
  }
  async loadSettings() {
    this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
  }
  async saveSettings() {
    await this.saveData(this.settings);
  }
  openDownloadModal() {
    if (!this.isAuthConfigured()) {
      new import_obsidian5.Notice("Please configure authentication in AxeraWikiClipper settings.");
      return;
    }
    new UrlModal(this.app, async (input) => {
      try {
        const pipeline = new Pipeline(this.app, this.settings);
        await pipeline.downloadByInput(input);
      } catch (e) {
        logger.error("Download failed", e);
        new import_obsidian5.Notice(`AxeraWikiClipper: ${e.message}`);
      }
    }).open();
  }
  isAuthConfigured() {
    const s = this.settings;
    if (s.authMode === "basic")
      return !!s.username && !!s.password;
    return !!s.cookie;
  }
};
